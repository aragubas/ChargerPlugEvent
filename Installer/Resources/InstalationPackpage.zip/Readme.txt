﻿ - Please open this file using a Monospaced font.

                             `'.---__,,,,,!ufz2c}xr~,.`                             
                      `'-_,",_------,:!!"_-,c#####@@@@#Q9f]~.`                      
                  `._:"_---">vujWR&QBBBBBBBQ##@@@@@@@@@@@@@@#8W)-`                  
               '_:,_-----*9QQBBBBBBBBBBBBB###@@@@@@@@@@@@@@@@@@@@gz^.               
            ',:,----------*RQQBBBBBBBBBBB####@@@@@@@@@@@@@@@@@@@@@@@#W*'            
         `-",----------_!r1EQQBBBBBBBBBBB####@@@@@@@@@@@@@@@@@@@@@@@@@@Qy:`         
       `_:_----------_28QQQQQBBBBBBBBBBBB#####@@@@@@@@@@@@@@@@@@@@@@@@@@@#H!`       
      -!,---------,,-,qQQQQQQBBBBBBBBBBBB#####@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#z,      
    `:"---!lc])if5&j_,WQQQQQQBBBBBBBBBBBB#####@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Q/`    
   .:-----cx--:28QQ&IRQQQQQQQBBBBBBBBBBBBB####@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#y.   
  -:------u2iI&88QQQQQQQQQQQQBBBBBBBBBBBB######@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@I-  
 .:-------l888888QQQQQQQQQQQQBBBBBBBBBBBB#######@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@k. 
`:_-------cg88888QQQQQQQQQQQQBBBBBBBBBBBB########@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#|`
-:--------:388888QQQQQQQQQQQQBBBQQ8g&EDRRDB#######@@@@###@@@@@@@@@@@@@@@@@@@@@@@@@5-
!:-----!|!-rg8888QQQQQQgg88g&&&0R999999999g&QB8&g##@@#@@@@##@@@@@@@@@@@@@@@@@@@@@@Q=
!,-----cgg9D88888QQQQQQ8&EDRRD99999999DRRERRD99EB#####@@@@@@@#@@@@@@@@@@@@@@@@@@@@#/
!,-----x&gR|*1d88QQQQQQQQQQ&g&90E0DDD9RRRR0D9R&########@@@@@@@@#@@@@@@@@@@@@@@@@@@#)
::-----_*y&gRsf&88QQQQQQQQQQBQQ&RRRRRR9999RRD9Dg8B######@@@@@@##@@@@@##@@@@@@@@@@@Q=
-!-----:lEEIx*v*ig8QQQQQQQQQQBQg&R9999999D0999999&########@@@@@@#@@##@@@@@@@@@@@@@A-
`!,----lg3:--_^2&88QQQQQQQQQQBB8EE9RD99999EQ9999RQ#######@@@@@@@@@##@@@@@@@@@@@@@#r`
 .!_---,x35zHE888QQQQQQQQQQQQBBBQB8&D9D999gB8&998#############@@@@@@@@@@@@@@@@@@@c. 
  -!------,^]2R88QQQ8au]us&QQBBBBBQgg8g&E&8&0gB################@@@@@@@@@@@@@@@@@z-  
   .!_--------:K8QQE)-----,\RQBBBBBBBBBBBB8&gQ####################@@@@@@@@@@@@#c.   
    `::--------~EQ&xxifx,---:5BBBBBBBBBBBB###########################@@@@@@@@8|`    
      -!,-------}Q88b_/ddr---}QBBBBBBBBBB############################@@@@@@#2,      
       `_:,-----cQQQ82x|uEi-_fBBBBBBBBBBB############################@@@@#f!`       
         `-:,---lQQQQQQQQ&z}2QBBBBBBBBBBB##############################Qc"`         
            `,:,!j&QQQQQQA5QQQ8&QBBBBBBBB###########################Qa*'            
               '_::::vDQ5:-__"_*8BBBBBBBB########################&2^.               
                  `._:!)1kj2jjycNQBBBBBBB####################&sr-`                  
                      `'-,"::,,_:~]AQBBBBB############QEWyv!'`                      
                             `'.--_:]yjfsHaHfzkl}xr=,.`                             
 2021 - Aragubas

 ChargerPlugEvent a neat little application to notify you when you plugged/unplugged your charger
 Very Usefull for Laptop users like me heh

 I created this app because you can't add a sound to Windows for plugging/unplugging the charger, so i made 
 ChargerPlugEvent to workaround this heh

 If you have any issues with application, please contact me!!
 The application is totally Free and Open Source (FOS) so you can modify the source code and make it better!

 Licensed under Apache 2.0 License!

  - Questions and Awnsers:


 Q: How do i change how the application behaves?:
 A: There is a file called 'properties.txt' located on root folder of instalation